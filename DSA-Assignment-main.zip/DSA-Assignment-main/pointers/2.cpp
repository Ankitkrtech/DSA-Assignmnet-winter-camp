#include<iostream>
using namespace std;

int main(){
// int a = 5;
// int*p = &a;
// int **q = &p;
// cout<<&a<<endl;
// cout<<a<<endl;
// cout<<p<<endl;
// cout<<*p<<endl;
// cout<<"q ka add"<<&q<<endl;
// cout<<**q<<endl;
// cout<<*q<<endl;
// cout<<"sab sahi chal raha hai";
// float  f = 10.5;
// float p = 2.5;
// float *ptr = &f;
// (*ptr)++;
// *ptr = p;
// cout<<*ptr<<" "<<f<< " "<< p;

// int a = 7;
// int b = 17;
// int *c =&b;
// *c = 7;
// cout<<a <<b<<endl;
// int arr[] ={1,2,3};
// cout<<arr<<endl;
// cout<<arr+1;
// cout<<&arr<<endl;
// cout<<&arr+1<<endl;
// char ch = 'a';
// char*ptr=&ch;
// ch++;
// cout<<ptr<<endl;
// // cout<<*ptr;

// int a = 7;
// int *c = &a;
// c = c+3;
// cout<< c<<endl;
// cout<<*c<<endl;
// double a = 10.5;
// double *d = &a;
// d = d+1;
// cout<<d;

// int a [5];
// int *c;
// cout<<sizeof(a)<<endl;
// cout<<sizeof(c);

// int a [] = {1,2,3,4};
// int *p  = a++;
// cout<<*p <<endl;

// int arr[] = {4,5,6,7};
// int *p = (arr+1);
// cout<<*arr +9;
char b[] = "xyz";
char *c = &b[0];
cout<<c<<endl;

}