#include<iostream>
using namespace std;


// void func(int *p ){
//     *p = *p+1;
// }
// void dummy(int *arr, int n){
//     cout<<sizeof(arr)<<endl;
// }
int main(){

// int a=5;
// // cout<<&a;
// int *p  = &a;
// cout<<sizeof(a);
// int *p = 0;
 
// cout<<*p<<endl;
// int a = 5;
// int *p = &a;
// cout<<"before "<<p<<endl;
// cout<<"before "<<*p<<endl;
// func(p);
// cout<<"aftre "<<p<<endl;
// cout<<"aftre "<<*p<<endl;
// int arr[] ={1,2,3};
// dummy(arr,3);
// // cout<<arr<<endl;
// cout<<*arr<<endl;
// cout<<*(arr+1)<<endl;
// cout<<*(arr+2)<<endl;
// // cout<<&arr<<endl;
// // cout<<&arr[0]<<endl;
//    int i = 0;
//    cout<<i[arr]<<endl;

// char ch[5 ] = "abcd";
// char *ptr = ch;
// cout<<ptr<<endl;

// char charc = 'B';
// char *ctr = &charc;
// cout<<ctr<<endl;
//q1
// int *p1;
// cout<<p1<<endl;
// cout<<*p1<<endl;
// cout<<&p1<<endl;
// //Q2
// int *p2 = 0;
// cout<<p2<<endl;
// cout<<*p2<<endl;
// cout<<&p2<<endl;

char sentance[] = "my name is manish keshri";
char *ptr = sentance;
cout<<ptr<<endl;
cout<<*ptr<<endl;
cout<<&ptr<<endl;

return 0; 
}  
 